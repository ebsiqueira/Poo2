# Classe responsável pela descrição do produto
class Produto:
     def __init__(self, codigo, preco, nome, tipo):
         self.codigo = codigo
         self.preco = preco
         self.nome = nome
         self.tipo = tipo

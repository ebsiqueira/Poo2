# Classe responsável pela descrição de funcionários
class Funcionario:
     def __init__(self, nome, senha):
         self.nome = nome
         self.senha = senha

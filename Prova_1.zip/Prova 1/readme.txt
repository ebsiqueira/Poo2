USO DO SISTEMA DE PAPELARIA:

BIBLIOTECAS NECESSÁRIAS: TKINTER

TELA INICIAL:
	Será apresentada uma tela para a realização de login.
	Usuário padrão: root
	Senha padrão: toor

MENU PRINCIPAL:

	CADASTRAR:
		Na tela de cadastro, serão solicitadas informações
		sobre o produto para que o mesmo seja descrito
		corretamente.

	CONSULTA:
		A tela de consulta apresenta um campo único para 
		digitação do código de identificação do produto.
		Caso o produto já tenha sido cadastrado, 
		aparecerão todas as informações do produto.

	SAIR:
		Botão que encerra a sessão do usuário na aplicação,
		perdendo todos os produtos previamente cadastrados.